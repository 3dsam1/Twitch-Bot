const { Client, Events, Collection, GatewayIntentBits } = require('discord.js');
const fs = require('fs');

const mongoose = require('mongoose')



const token = process.env.D_TOKEN

const client = new Client({  // Initiates a new client with the specified intents.
	intents: [
		GatewayIntentBits.Guilds,
		GatewayIntentBits.GuildMessages, // Reads messages
		GatewayIntentBits.MessageContent // Reads the content of messages.

	]
});




client.commands = new Collection();

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {

	const command = require(`./commands/${file}`)

	if ('data' in command && 'execute' in command) {
		client.commands.set(command.data.name, command);
	}
	else {
		console.log(`[WARNING] The command at ${command}, is missing a required "data" or "execute" property.`);
	}


}


client.once(Events.ClientReady, async client => { // Once bot is live.


	console.log("Ready!")

	const command1 = client.commands.get('check-live');
	const command2 = client.commands.get('old-live')




	command1.execute(client)
	command2.execute(client)

	setInterval(() => { // Checks for any new live user and then checks if the previous live users are still live.  

		command1.execute(client)
		command2.execute(client)


	}, process.env.REFRESH_TIME * 1000 * 60);

	const adminProfile = require('./schemas/admin_schema')
	let roleId = process.env.D_ADMIN_ROLE_ID;

	if (roleId) { // Checks to see if it has been provided in the .env file.

		let found = await adminProfile.findOne({discord_id: roleId})

		if(!found){
		await adminProfile.create({ discord_id: process.env.D_ADMIN_ROLE_ID, name: "Admin_Role" })
		}

	}




})



client.on(Events.InteractionCreate, async interaction => {


	if (!interaction.isChatInputCommand()) return;  // Checks for if its a slash command.


	const command = client.commands.get(interaction.commandName);



	if (!command) { // If we can't find the command. 

		console.error(`[WARNING] No command matching ${interaction.commandName} was found.`);
		interaction.reply("This command is no longer supported. If you feel this shouldn't be the case, please contact support");

		return;
	}



	try {

		switch (interaction.commandName) {

			case 'check-live':
				await interaction.reply(`Checking for any new lives.`)
				await command.execute(client)
				interaction.editReply('Succesfully checked for any new live users. ')

				break;

			case 'old-live':

				await interaction.reply('Checking the previous live users.')

				await command.execute(client)

				interaction.editReply('Succuesfully checked for the previous live users.')

				break;

				case 'add-admin':
					case 'add-channel':
					case 'add-user':
					case 'remove-channel':
					case 'remove-user': 
	
	
					const adminModel = require('./schemas/admin_schema')
	
					let adminRole = await adminModel.findOne({ name: 'Admin_Role' });
	
					if(!adminRole){
	
						interaction.reply({content: 'The bot has not been intialized yet. Please intialize it and then try again!', ephemeral: true})
						
						break;
					}
	
			default:

				await command.execute(interaction)

				break;

		}



	} catch (err) { // Catch any error's while running the command. 
		console.log(`[ERROR]: \n` + err)
		
	
	}
	



});


client.login(token)

const username = process.env.MONGO_INITDB_ROOT_USERNAME
const password = process.env.MONGO_INITDB_ROOT_PASSWORD


const url = `mongodb://${username}:${password}@mongo:27017/twitch_bot?authSource=admin`


mongoose.connect(url, { useNewUrlParser: true})


mongoose.connection.on('connected', async connection => {

	console.log('[MONGO] Succesfully connected to Database.');
})

mongoose.connection.on('disconnect', async () => {

	console.log(`[MONGO] - [WARNING] Disconnected from Database.`);

})	
